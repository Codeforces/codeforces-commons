#include <iostream>
#include <cstdlib>
#include <stdio.h>
#include <memory.h>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <iomanip>
#include <algorithm>
#include <math.h>

using namespace std;

#define forn(i,n) for(int i = 0; i< int(n); i++)
#define for1(i,n) for(int i = 1; i<= int(n); i++)
#define pb push_back
#define mp make_pair

const int INF = 1e9;
const double PI = acos(-1.0);
const int N = 1010;

typedef long long li;

template<typename T> T sqr(const T &x) {
    return x * x;
}

inline li sum(li lf, li rg) {
    li sum = (lf + rg) * ((rg - lf + 1) / 2);
    if ((rg - lf + 1) % 2 == 1)
        sum += (rg + lf) / 2;
    return sum;
}

inline li min64(li a, li b) {
    return a < b ? a : b;
}

inline li abs64(li a) {
    return a < 0 ? -a : a;
}

li calc(li lf, li t) {
    double d = 1 - 4 * (2 * t - sqr(lf) + 1);
    li rg = (-1 + (li) sqrt(d)) / 2;
    d = 4 - 4 * (2 * lf - sqr(lf) - 2 * t);
    rg = min64(rg, (-2 + (li) sqrt(d)) / 2);
    return abs64(rg);
}

int main(){
#ifndef ONLINE_JUDGE
    freopen("input.txt", "rt", stdin);
#endif
    vector<pair<li, li> > ans;
    li t;
    scanf("%I64d", &t);
    li lf = 1;
    li rg = calc(lf, t);
    while (lf <= t / 2 + 1) {
        li val = sum(lf, rg);
        if (val < t) {
            ++rg;
        } else if (val == t) {
            ans.pb(mp(lf, rg));
            //printf("[%I64d, %I64d]\n", lf, rg);
            lf = rg;
            rg = calc(lf, t);
        } else {
            ++lf;
            rg = calc(lf, t);
        }
    }
    int size = (int) ans.size();
    printf("%d\n", size);
    forn(i, size)
        printf("[%I64d, %I64d]\n", ans[i].first, ans[i].second);
    return 0;
}    